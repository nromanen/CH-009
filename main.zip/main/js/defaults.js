var App = App || {};

( function () {
	
	App = {
	
		Models: App.Models || {},
		Views: App.Views || {},
		Collections: App.Collections || {},
		dbConnector: App.dbConnector || {},
		Events : _.extend( {}, Backbone.Events )
	
	};
	
})();